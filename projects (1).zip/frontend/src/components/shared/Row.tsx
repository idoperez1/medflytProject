import styled from "styled-components/macro";
import Flex from "./Flex";

const Row = styled(Flex)``;

export default Row;
