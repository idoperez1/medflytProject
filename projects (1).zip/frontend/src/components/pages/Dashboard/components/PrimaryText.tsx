import styled from "styled-components/macro";

export const PrimaryText = styled.div`
    font-weight: 600;
    font-size: 24px;
    line-height: 29px;
    color: #ffffff;
    text-transform: uppercase;
`;
