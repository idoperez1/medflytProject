const config = {
    API_HOST_URL: "http://localhost:3000"
};

export default config;
